const express = require('express');
const app = express();

// Middleware to parse JSON bodies
app.use(express.json());

// Port configuration
const PORT = process.env.PORT || 3000;

// Webhook endpoint for Monday.com
app.post('/webhook/monday', (req, res) => {
  console.log('====================================');
  console.log('Monday.com Webhook Received!');
  console.log('====================================');
  console.log('Headers:', req.headers);
  console.log('Body:', JSON.stringify(req.body, null, 2));
  console.log('====================================');
  
  // Send success response back to Monday.com
  res.status(200).json({
    // success: true,
    // message: 'Webhook received successfully',
    data: req.body
  });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'Server is running' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(` Webhook endpoint: http://localhost:${PORT}/webhook/monday`);
  console.log(` Health check: http://localhost:${PORT}/health`);
});
